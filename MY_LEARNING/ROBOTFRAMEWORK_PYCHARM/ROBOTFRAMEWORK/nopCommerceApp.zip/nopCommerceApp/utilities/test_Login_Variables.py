class Test_Login_Variables:
    baseURL="https://admin-demo.nopcommerce.com"
    username="admin@yourstore.com"
    password="admin"