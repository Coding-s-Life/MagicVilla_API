import logging


class LogGen:
    @staticmethod
    def loggen():
        logging.basicConfig(filename=".\\Logs\\automation.log", level=logging.DEBUG,
                            format = "%(asctime)s: %(levelname)s: %(message)s', datefmt='%m%d/%Y %I:%M:%S %p"
                            ,filemode='w')

        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)
        #format = "%(asctime)s: %(levelname)s: %(message)s', datefmt='%m%d/%Y %I:%M:%S %p"
        #logger.__format__(str(format))
        return logger
