import pytest
from selenium import webdriver
from pageObjects.LoginPage import Login
# from utilities.test_Login_Variables import Test_Login_Variables
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen


class Test_001:
    baseURL = ReadConfig.getApplicationURL()
    username = ReadConfig.getUsername()
    password = ReadConfig.getPassword()

    logger = LogGen.loggen()

    def test_home_page_title(self, setup):
        self.logger.info("************** test_home_page_title test case ************* ")
        self.logger.info("************** Verifying Home Page Title ************* ")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        act_title = self.driver.title
        if act_title == "Your store. Login":
            assert True
            self.driver.close()
            self.logger.info("Home Page Title is passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_Login_test_home_page_title.png")
            self.driver.close()
            self.logger.error("Home Page Title is Failed")
            assert False

    def test_login_happy_path(self, setup):
        self.logger.info("************ test_login_happy_path test case ***************")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        login_page = Login(self.driver)

        login_page.setUserName(self.username)
        login_page.setPassword(self.password)
        login_page.clickLogin()
        logged_in_title = self.driver.title
        if logged_in_title == "Dashboard / nopCommerce administration":
            self.driver.close()
            self.logger.info("A successful login happened and test_login_happy_path test is passed")
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_Login_test_login_happy_path.png")
            self.driver.close()
            self.logger.error("test_Login_test happy path test case is failed")
            assert False
