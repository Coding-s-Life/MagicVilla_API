print("ibaad calculator")
num1 =int(input("Enter the first number: "))
num2=int(input("enter the second number: "))

result=num1+num2
print("addition between :", num1,num2)