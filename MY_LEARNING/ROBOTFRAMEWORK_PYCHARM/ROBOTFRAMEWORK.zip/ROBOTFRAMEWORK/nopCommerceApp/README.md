# robotframework-demorobotlibrary
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0) [![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black) [![CodeQL](https://github.com/joergschultzelutter/robotframework-demorobotlibrary/actions/workflows/codeql.yml/badge.svg)](https://github.com/joergschultzelutter/robotframework-demorobotlibrary/actions/workflows/codeql.yml)

Accompanying code repository to the BCP workshop [Create a Robot Framework Keyword Library with Python](https://tech.bertelsmann.com/en/blog/articles/workshop-create-a-robot-framework-keyword-library-with-python)
