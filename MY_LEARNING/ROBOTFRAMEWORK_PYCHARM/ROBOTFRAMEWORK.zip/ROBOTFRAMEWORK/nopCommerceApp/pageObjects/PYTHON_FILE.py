from robot.api.deco import keyword
import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service


class PYTHON_FILE:
    textbox_username_id = "Email"
    textbox_password_id = "Password"
    button_login_xpath = "//button[@class='button-1 login-button']"
    link_logout_link_text = "Logout"
    driver = webdriver.Firefox()
    # def __init__(self, driver):
    #     self.driver = driver
    #     service = Service(
    #         executable_path=r'C:/Users/munee/.wdm/drivers/geckodriver/win64/v0.34.0/',
    #         service_log_path=os.devnull,
    #     )
    #     options = webdriver.FirefoxOptions()
    #     options.add_argument('--headless')
    #     options.add_argument('--no-sandbox')
    #     options.add_argument('--disable-dev-shm-usage')
    #     driver = webdriver.Firefox(service=service, options=options)

    # def __init__(self):
    #     #self.driver = webdriver.Firefox()
    #     pass

    @keyword('Set Driver')
    def set_driver(self):
        self.driver = webdriver.Firefox()

    @keyword('Set Username')
    def set_user_name(self, username):
        self.driver.find_element("id", self.textbox_username_id).clear()
        self.driver.find_element("id", self.textbox_username_id).send_keys(username)

    @keyword('Set Password')
    def set_password(self, password):
        self.driver.find_element("id", self.textbox_password_id).clear()
        self.driver.find_element("id", self.textbox_password_id).send_keys(password)

    @keyword('Click Login Button')
    def click_login(self):
        self.driver.find_element("xpath", self.button_login_xpath).click()

    @keyword('Click Logout Button')
    def click_logout(self):
        self.driver.find_element("link_text", self.link_logout_link_text).click()
