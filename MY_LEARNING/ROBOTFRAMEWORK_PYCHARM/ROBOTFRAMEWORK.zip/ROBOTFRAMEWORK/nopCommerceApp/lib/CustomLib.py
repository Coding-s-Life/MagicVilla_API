import random
import string
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
__version__ = '1.0.0'


class CustomLib(object):
    ROBOT_LIBRARY_VERSION = __version__
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    #textbox_search_field = "APjFqb"
    #textbox_password_id = "Password"
    button_login_xpath = "//button[@class='button-1 login-button']"
    link_logout_link_text = "Logout"
    textbox_email = "Email"
    textbox_password = "Password"



    # I declare it to be as Firefox
    # driver = webdriver.Firefox()

    def __init__(self, driver=None):
        if driver:
            self.driver = driver

    def set_driver(self, driver):
        self.driver = driver

    def get_driver(self):
        return self.driver

    # def open_webpage(self):
    #     self.driver.get("www.google.com")
    #def set_input_text(self, text):
     #   self.driver.find_element(By.ID, self.textbox_search_field).clear()
      #  self.driver.find_element(By.ID, self.textbox_search_field).send_keys(text)
       # self.driver.find_element(By.ID, self.textbox_search_field).send_keys(Keys.RETURN)

    def set_email(self, email):
        self.driver.find_element(By.ID, self.textbox_email).clear()
        self.driver.find_element(By.ID, self.textbox_email).send_keys(email)

    def set_password(self, password):
        self.driver.find_element(By.ID, self.textbox_password).clear()
        self.driver.find_element(By.ID, self.textbox_password).send_keys(password)

    def click_login_button(self):
        self.driver.find_element(By.XPATH, self.button_login_xpath).click()

    def click_logout_button(self):
        self.driver.find_element(By.LINK_TEXT, self.link_logout_link_text).click()