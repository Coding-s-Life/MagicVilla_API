from selenium import webdriver
import pytest

@pytest.fixture()
def setup():
    driver = webdriver.Firefox()
    print("Firefox is launched ")
    return driver
#################################### pytest HTML REPORT ##################################
def pytest_configure(config):
    config._metadata = {
        "Tester": "Muneer",
        "Project Name": "Hybrid Framework Practice",
        "Module": "Customers"
    }
    # config.metadata['Project Name']= 'nop Commerce App'
    # config.metadata['Module Name']= 'Customers'
    # config.metadata['Tester Name']= 'Muneer'

@pytest.mark.optionalhook
def pytest_metadata(metadata):
    metadata.pop("JAVA_HOME", None)
    metadata.pop("Plugins", None)



# @pytest.fixture()
# def setup(browser):
#     if browser == "chrome" or browser == "CHROME" or browser == "Chrome":
#         driver = webdriver.Chrome()
#         print("Chrome is launched ")
#         return driver
#     elif browser == "firefox" or browser == "FIREFOX" or browser == "Firefox":
#         driver = webdriver.Firefox()
#         print("Firefox is launched ")
#         return driver
#     else:
#         driver = webdriver.Firefox()
#         return driver
#
#
#
# def pytest_adoption(parser):  # This will get the value from the CLI/hooks
#     parser.addoption("--browser")
#
#
# # Now to pass the value of the "--browser" argument we need this fixture
# @pytest.fixture()
# def browser(request):
#     return request.config.getoption("--browser")
