from pageObjects.PYTHON_FILE import PYTHON_FILE
# from utilities.test_Login_Variables import Test_Login_Variables
from robot.api.deco import keyword

from lib.LoginPage import LoginPage
from utilities.customLogger import LogGen
# from utilities.test_Login_Variables import Test_Login_Variables
from utilities.readProperties import ReadConfig


class Test_001:
    baseURL = ReadConfig.getApplicationURL()
    username = ReadConfig.getUsername()
    password = ReadConfig.getPassword()

    logger = LogGen.loggen()

    @keyword("Verify Home Page Title Is Correct")
    def test_home_page_title(self, setup):
        self.logger.info("************** test_home_page_title test case ************* ")
        self.logger.info("************** Verifying Home Page Title ************* ")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        act_title = self.driver.title
        if act_title == "Your store. Login":
            assert True
            self.driver.close()
            self.logger.info("Home Page Title is passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_Login_test_home_page_title.png")
            self.driver.close()
            self.logger.error("Home Page Title is Failed")
            assert False

    @keyword("Test Login Happy Path")
    def test_login_happy_path(self, setup):
        self.logger.info("************ test_login_happy_path test case ***************")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        login_page = LoginPage(self.driver)

        login_page.set_user_name(self.username)
        login_page.set_password(self.password)
        login_page.click_login()
        logged_in_title = self.driver.title
        if logged_in_title == "Dashboard / nopCommerce administration":
            self.driver.close()
            self.logger.info("A successful login happened and test_login_happy_path test is passed")
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_Login_test_login_happy_path.png")
            self.driver.close()
            self.logger.error("test_Login_test happy path test case is failed")
            assert False
