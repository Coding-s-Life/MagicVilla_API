import time

from lib.LoginPage import Login
# from utilities.test_Login_Variables import Test_Login_Variables
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from utilities import XLUtils


class Test_002_DDT_Login:
    baseURL = ReadConfig.getApplicationURL()
    pathToTestDataFile = ".//TestData/LoginData.xlsx"
    logger = LogGen.loggen()

    def test_login_happy_path_ddt(self, setup):
        self.logger.info("************ test_login_happy_path_ddt test case ***************")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        login_page = Login(self.driver)

        # here we are getting the XLUtils methods to get user name and password data for testing
        self.rowsInExcel = XLUtils.getRowCount(self.pathToTestDataFile, 'Sheet1')
        print("rowsInExcel: ", self.rowsInExcel)

        list_Status = []  # Empty List

        for r in range(2, self.rowsInExcel + 1):
            self.usernameFromExcel = XLUtils.readData(self.pathToTestDataFile, 'Sheet1', r, 1)
            self.passwordFromExcel = XLUtils.readData(self.pathToTestDataFile, 'Sheet1', r, 2)
            self.expectedResultFromExcel = XLUtils.readData(self.pathToTestDataFile, 'Sheet1', r, 3)
            login_page.setUserName(self.usernameFromExcel)
            login_page.setPassword(self.passwordFromExcel)
            login_page.clickLogin()
            time.sleep(5)
            logged_in_title = self.driver.title
            expected_Title = "Dashboard / nopCommerce administration"

            if logged_in_title == expected_Title:
                if self.expectedResultFromExcel == "Pass":
                    login_page.clickLogout()
                    self.driver.close()
                    self.logger.info("A successful login happened and test_login_happy_path test is passed")
                    list_Status.append("Pass")
                    assert True
                elif self.expectedResultFromExcel == "Fail":
                    self.driver.save_screenshot(".\\Screenshots\\" + "test_Login_test_login_happy_path.png")
                    self.driver.close()
                    self.logger.error("test_Login_test happy path test case is failed")
                    list_Status.append("Fail")
                    login_page.clickLogout()
                    assert False
            elif logged_in_title != expected_Title:
                if self.expectedResultFromExcel == "Pass":
                    self.logger.info("**** Failed because the login happened but the title of the web page is "
                                     "different than the one expected ******")
                    list_Status.append("Fail")
                elif self.expectedResultFromExcel == "Fail":
                    self.logger.info("***** Passed because the login failed which is expected if the expected title "
                                     "does not match from the actual ******")
                    list_Status.append("Pass")
        if "Fail" not in list_Status:
            self.logger.info("LOGIN DDT test case is passed")
            print("LOGIN DDT test case is passed")
            self.driver.close()
            assert True
        else:
            self.logger.error("LOGIN DDT test case is Failed")
            print("LOGIN DDT test case is FAILED")
            self.driver.close()
            assert False
